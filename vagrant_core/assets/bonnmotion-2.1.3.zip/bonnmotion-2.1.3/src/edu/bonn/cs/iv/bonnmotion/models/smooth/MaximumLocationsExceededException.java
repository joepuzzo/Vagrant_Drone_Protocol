package edu.bonn.cs.iv.bonnmotion.models.smooth;

public class MaximumLocationsExceededException extends SmoothException {
	public MaximumLocationsExceededException(String message){
		super(message);
	}
}
