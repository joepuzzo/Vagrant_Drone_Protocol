package edu.bonn.cs.iv.bonnmotion.models.smooth;

public class SmoothException extends Exception {
	public SmoothException(String message){
		super(message);
	}
}
