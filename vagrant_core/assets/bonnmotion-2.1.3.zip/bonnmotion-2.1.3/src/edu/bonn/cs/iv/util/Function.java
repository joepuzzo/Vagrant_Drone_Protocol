package edu.bonn.cs.iv.util;

public interface Function {
    public double calculate(double x);
}
