package edu.bonn.cs.iv.util;

/**
 * Classes have to implement this interface to be stored in SortedList
 */
public interface Sortable {
	public int getKey();
}
