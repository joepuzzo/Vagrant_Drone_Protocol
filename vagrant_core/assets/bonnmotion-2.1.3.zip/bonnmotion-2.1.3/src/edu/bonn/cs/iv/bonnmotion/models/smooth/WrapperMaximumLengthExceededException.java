package edu.bonn.cs.iv.bonnmotion.models.smooth;

public class WrapperMaximumLengthExceededException extends SmoothException {
	public WrapperMaximumLengthExceededException(String message){
		super(message);
	}
}
